from django.urls import path
from EmployeeApps import views

urlpatterns = [
    path('addEmployee',views.addEmployee)
]