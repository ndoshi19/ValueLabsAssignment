from rest_framework import serializers
from .models import Employee, Address

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta():
        model = Employee
        fields = ['employeeCode','employeeName','phone','deptId']

class AddressSerializer(serializers.ModelSerializer):
    class Meta():
        model = Address
        fields = ['employeeId','addressLine1','addressLine2','city','state','zipCode']