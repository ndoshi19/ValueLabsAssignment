from django.db import models

# Create your models here.
import EmployeeApps.models



class Department(models.Model):
    name = models.CharField(max_length=25)

class Employee(models.Model):
    employeeCode = models.CharField(max_length=50)
    employeeName = models.CharField(max_length=50)
    phone = models.CharField(max_length=14)
    deptId = models.ForeignKey(Department,on_delete=models.CASCADE)


class Address(models.Model):
    employeeId = models.ForeignKey(Employee, on_delete=models.CASCADE)
    addressLine1 = models.TextField()
    addressLine2 = models.TextField(null=True)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    zipCode = models.CharField(max_length=20)
