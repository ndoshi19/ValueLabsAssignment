from django.http import JsonResponse
from django.shortcuts import render
from .serializers import EmployeeSerializer, AddressSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
# Create your views here.


@api_view(['POST'])
def addEmployee(request):
    empSerial = EmployeeSerializer(data=request.data)
    if empSerial.is_valid():
        record = empSerial.save()

        addressData = request.data["address"]
        for address in addressData:
            address['employeeId'] = record.id
            addSerial = AddressSerializer(data=address)

            if addSerial.is_valid():
                addSerial.save()
        return Response({"EmployeeId":record.id})

    else:
        return Response(status=status.HTTP_400_BAD_REQUEST)


